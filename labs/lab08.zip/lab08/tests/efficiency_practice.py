test = {
  'name': 'efficiency_practice',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': '410680eed0265cc95d2df7f947d93f67',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The count_partitions function runs in ____ time in the length of its input.'
        },
        {
          'answer': '6f968a7981449f66717a39a4fb8e2b85',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The is_palindrome function runs in ____ time in the length of its input.'
        },
        {
          'answer': '25d8b2ea726dc06ace8d694844efb6d0',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The binary_search function runs in ____ time in the length of its input.'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
